
#!/usr/bin/env python3
"""
MSS Lite v1
A dependency-free local business operations application using Python's standard library.
"""

from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, quote
from http import cookies
import sqlite3
import hashlib
import hmac
import secrets
import json
import os
import html
import csv
import io
import mimetypes
from email.parser import BytesParser
from email.policy import default as email_policy
import shutil
from pathlib import Path
from datetime import datetime, timedelta, timezone

BASE_DIR = Path(__file__).resolve().parent
# On a hosted service, set MSS_DATA_ROOT to a persistent mounted disk.
DATA_ROOT = Path(os.environ.get("MSS_DATA_ROOT", str(BASE_DIR))).resolve()
DATA_DIR = DATA_ROOT / "data"
UPLOAD_DIR = DATA_ROOT / "uploads"
BACKUP_DIR = DATA_ROOT / "backups"
DB_PATH = DATA_DIR / "mss_lite.db"
HOST = os.environ.get("MSS_HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", os.environ.get("MSS_PORT", "8501")))

DATA_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)
BACKUP_DIR.mkdir(exist_ok=True)

APP_NAME = "MSS Lite"

NAV_ITEMS = [
    ("Dashboard", "/"),
    ("Documents", "/documents"),
    ("Tasks", "/tasks"),
    ("Training", "/training"),
    ("Search", "/search"),
    ("Reports", "/reports"),
    ("Administration", "/admin"),
]

CSS = """
:root {
  --bg:#f5f7fb; --panel:#ffffff; --text:#172033; --muted:#667085;
  --border:#dfe3ea; --accent:#3157d5; --accent2:#e9efff; --danger:#b42318;
  --success:#067647; --warning:#b54708;
}
*{box-sizing:border-box}
body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:var(--bg);color:var(--text)}
a{color:var(--accent);text-decoration:none}
.shell{display:grid;grid-template-columns:230px 1fr;min-height:100vh}
.sidebar{background:#111827;color:white;padding:22px 16px;position:sticky;top:0;height:100vh}
.brand{font-size:20px;font-weight:750;margin:2px 8px 24px}
.nav a{display:block;color:#d1d5db;padding:10px 12px;border-radius:10px;margin:4px 0}
.nav a:hover,.nav a.active{background:#263244;color:white}
.sidebar-footer{position:absolute;bottom:18px;left:16px;right:16px;color:#9ca3af;font-size:13px}
.main{padding:28px;min-width:0}
.topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;gap:12px}
h1{font-size:26px;margin:0}
h2{font-size:19px;margin:0 0 14px}
.subtitle{color:var(--muted);margin-top:5px}
.userbox{display:flex;align-items:center;gap:10px;color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}
.card{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px}
.metric-label{color:var(--muted);font-size:13px}
.metric-value{font-size:29px;font-weight:750;margin-top:6px}
.two-col{display:grid;grid-template-columns:1.4fr 1fr;gap:18px;margin-top:18px}
table{width:100%;border-collapse:collapse}
th,td{text-align:left;padding:11px 10px;border-bottom:1px solid var(--border);vertical-align:top}
th{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.04em}
.badge{display:inline-block;padding:4px 8px;border-radius:999px;background:var(--accent2);color:var(--accent);font-size:12px}
.badge.success{background:#ecfdf3;color:var(--success)}
.badge.warning{background:#fffaeb;color:var(--warning)}
.badge.danger{background:#fef3f2;color:var(--danger)}
.actions{display:flex;gap:8px;flex-wrap:wrap}
button,.button{border:0;border-radius:9px;padding:9px 13px;background:var(--accent);color:white;cursor:pointer;font:inherit;display:inline-block}
.button.secondary,button.secondary{background:white;color:var(--text);border:1px solid var(--border)}
.button.danger,button.danger{background:var(--danger)}
form.inline{display:inline}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
label{display:block;color:var(--muted);font-size:13px;margin-bottom:5px}
input,select,textarea{width:100%;border:1px solid var(--border);border-radius:9px;padding:10px;background:white;color:var(--text);font:inherit}
textarea{min-height:100px;resize:vertical}
.full{grid-column:1 / -1}
.toolbar{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap}
.notice{padding:11px 14px;border-radius:10px;margin-bottom:16px;background:#ecfdf3;color:var(--success)}
.notice.error{background:#fef3f2;color:var(--danger)}
.empty{color:var(--muted);padding:22px;text-align:center}
.login-wrap{min-height:100vh;display:grid;place-items:center;padding:20px}
.login-card{width:min(420px,100%);background:white;border:1px solid var(--border);border-radius:16px;padding:26px}
.login-card h1{margin-bottom:4px}
.login-card form{margin-top:20px}
.login-card .field{margin-bottom:14px}
.small{font-size:13px;color:var(--muted)}
.kpi-list{display:grid;gap:10px}
.kpi-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid var(--border)}
.search-results{display:grid;gap:12px}
.result{border:1px solid var(--border);border-radius:12px;padding:14px;background:white}
@media(max-width:900px){.shell{grid-template-columns:1fr}.sidebar{height:auto;position:static}.nav{display:flex;overflow:auto}.nav a{white-space:nowrap}.sidebar-footer{display:none}.grid{grid-template-columns:repeat(2,1fr)}.two-col{grid-template-columns:1fr}}
@media(max-width:600px){.main{padding:18px}.grid,.form-grid{grid-template-columns:1fr}.topbar{align-items:flex-start;flex-direction:column}.full{grid-column:auto}}
"""


class UploadedFile:
    def __init__(self, filename, data):
        self.filename = filename
        self.file = io.BytesIO(data)

class MultiForm(dict):
    def getfirst(self, key, default=None):
        value = self.get(key, default)
        return value

def utcnow():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()

def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 210_000)
    return salt.hex() + "$" + digest.hex()

def verify_password(password, encoded):
    try:
        salt_hex, digest_hex = encoded.split("$", 1)
        check = hash_password(password, bytes.fromhex(salt_hex)).split("$",1)[1]
        return hmac.compare_digest(check, digest_hex)
    except Exception:
        return False

def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'viewer',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions(
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id),
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS documents(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT,
      status TEXT NOT NULL DEFAULT 'draft',
      owner_id INTEGER REFERENCES users(id),
      review_date TEXT,
      version INTEGER NOT NULL DEFAULT 1,
      filename TEXT,
      stored_filename TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tasks(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      assigned_to INTEGER REFERENCES users(id),
      due_date TEXT,
      priority TEXT NOT NULL DEFAULT 'normal',
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL,
      completed_at TEXT
    );
    CREATE TABLE IF NOT EXISTS courses(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS training_assignments(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      course_id INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      due_date TEXT,
      status TEXT NOT NULL DEFAULT 'assigned',
      completed_at TEXT,
      UNIQUE(course_id,user_id)
    );
    CREATE TABLE IF NOT EXISTS audit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      action TEXT NOT NULL,
      entity_type TEXT NOT NULL,
      entity_id INTEGER,
      detail TEXT,
      created_at TEXT NOT NULL
    );
    """)
    if con.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
        con.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                    ("Administrator","admin@mss.local",hash_password("ChangeMe123!"),"admin",utcnow()))
        admin_id = con.execute("SELECT id FROM users WHERE email='admin@mss.local'").fetchone()[0]
        now = utcnow()
        con.execute("""INSERT INTO documents(title,category,description,status,owner_id,review_date,version,created_at,updated_at)
                       VALUES(?,?,?,?,?,?,?,?,?)""",
                    ("Welcome to MSS Lite","Guide","Start here. Replace sample records with your own business content.",
                     "published",admin_id,(datetime.now()+timedelta(days=180)).date().isoformat(),1,now,now))
        con.execute("INSERT INTO tasks(title,description,assigned_to,due_date,priority,status,created_at) VALUES(?,?,?,?,?,?,?)",
                    ("Change the default administrator password","Open Administration and update the administrator account.",
                     admin_id,(datetime.now()+timedelta(days=1)).date().isoformat(),"high","open",now))
        con.execute("INSERT INTO courses(title,description,created_at) VALUES(?,?,?)",
                    ("MSS Lite Orientation","Learn how documents, tasks, and training work together.",now))
        course_id = con.execute("SELECT last_insert_rowid()").fetchone()[0]
        con.execute("INSERT INTO training_assignments(course_id,user_id,due_date,status) VALUES(?,?,?,?)",
                    (course_id,admin_id,(datetime.now()+timedelta(days=14)).date().isoformat(),"assigned"))
    con.commit()
    con.close()

def escape(v):
    return html.escape(str(v or ""))

def status_badge(status):
    cls = "success" if status in ("published","completed","active") else "warning" if status in ("review","in_progress","assigned") else "danger" if status in ("overdue","rejected","disabled") else ""
    return f'<span class="badge {cls}">{escape(status.replace("_"," ").title())}</span>'

class MSSHandler(BaseHTTPRequestHandler):
    server_version = "MSSLite/1.0"

    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def send_text(self, body, status=200):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def send_html(self, body, status=200, headers=None):
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Content-Length",str(len(data)))
        self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","same-origin")
        self.send_header("Cache-Control","no-store")
        if headers:
            for k,v in headers:
                self.send_header(k,v)
        self.end_headers()
        self.wfile.write(data)

    def redirect(self, location, cookie=None):
        self.send_response(303)
        self.send_header("Location",location)
        if cookie:
            self.send_header("Set-Cookie",cookie)
        self.end_headers()

    def current_user(self):
        raw = self.headers.get("Cookie","")
        jar = cookies.SimpleCookie()
        try: jar.load(raw)
        except Exception: return None
        morsel = jar.get("mss_session")
        if not morsel: return None
        token = morsel.value
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        con = db()
        row = con.execute("""SELECT users.* FROM sessions JOIN users ON users.id=sessions.user_id
                             WHERE sessions.token_hash=? AND sessions.expires_at>? AND users.active=1""",
                          (token_hash,utcnow())).fetchone()
        con.close()
        return row

    def require_user(self):
        user = self.current_user()
        if not user:
            self.redirect("/login")
            return None
        return user

    def parse_form(self):
        ctype = self.headers.get("Content-Type","")
        length = int(self.headers.get("Content-Length","0") or 0)
        raw = self.rfile.read(length)
        if ctype.startswith("multipart/form-data"):
            message = BytesParser(policy=email_policy).parsebytes(
                b"Content-Type: " + ctype.encode("utf-8") + b"\r\n"
                b"MIME-Version: 1.0\r\n\r\n" + raw
            )
            form = MultiForm()
            if message.is_multipart():
                for part in message.iter_parts():
                    disposition = part.get("Content-Disposition", "")
                    if "form-data" not in disposition:
                        continue
                    name = part.get_param("name", header="Content-Disposition")
                    filename = part.get_filename()
                    payload = part.get_payload(decode=True) or b""
                    if filename:
                        form[name] = UploadedFile(filename, payload)
                    else:
                        charset = part.get_content_charset() or "utf-8"
                        form[name] = payload.decode(charset, errors="replace")
            return form
        body = raw.decode("utf-8")
        return {k:v[-1] for k,v in parse_qs(body).items()}

    def audit(self, user_id, action, entity_type, entity_id=None, detail=""):
        con=db()
        con.execute("INSERT INTO audit_log(user_id,action,entity_type,entity_id,detail,created_at) VALUES(?,?,?,?,?,?)",
                    (user_id,action,entity_type,entity_id,detail,utcnow()))
        con.commit(); con.close()

    def layout(self, user, title, content, active="", notice=""):
        nav = "".join(f'<a class="{"active" if active==label else ""}" href="{url}">{label}</a>' for label,url in NAV_ITEMS if not (label=="Administration" and user["role"]!="admin"))
        notice_html = f'<div class="notice">{escape(notice)}</div>' if notice else ""
        return f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>{escape(title)} · {APP_NAME}</title><style>{CSS}</style></head><body>
        <div class="shell"><aside class="sidebar"><div class="brand">MSS Lite</div><nav class="nav">{nav}</nav>
        <div class="sidebar-footer">Local Business Operations System<br>Version 1.0</div></aside>
        <main class="main"><div class="topbar"><div><h1>{escape(title)}</h1><div class="subtitle">Modern Success System</div></div>
        <div class="userbox">{escape(user["name"])} · {escape(user["role"].title())} <a class="button secondary" href="/logout">Sign out</a></div></div>
        {notice_html}{content}</main></div></body></html>"""

    def do_GET(self):
        if urlparse(self.path).path == "/health":
            return self.send_text("ok", 200)
        path = urlparse(self.path).path
        qs = parse_qs(urlparse(self.path).query)
        if path == "/login": return self.login_page()
        if path == "/logout": return self.logout()
        if path.startswith("/uploads/"): return self.download_file(path.split("/")[-1])
        if path.startswith("/export/"): return self.export_csv(path.split("/")[-1])
        user = self.require_user()
        if not user: return
        routes = {
            "/": self.dashboard, "/documents": self.documents, "/tasks": self.tasks,
            "/training": self.training, "/search": self.search, "/reports": self.reports,
            "/admin": self.admin
        }
        fn = routes.get(path)
        if fn: return fn(user, qs)
        self.send_html(self.layout(user,"Not Found",'<div class="card">Page not found.</div>'),404)

    def do_POST(self):
        path = urlparse(self.path).path
        if path == "/login": return self.login_submit()
        user = self.require_user()
        if not user: return
        form = self.parse_form()
        actions = {
            "/documents/create": self.document_create,
            "/documents/status": self.document_status,
            "/tasks/create": self.task_create,
            "/tasks/status": self.task_status,
            "/training/course/create": self.course_create,
            "/training/assign": self.training_assign,
            "/training/status": self.training_status,
            "/admin/user/create": self.user_create,
            "/admin/password": self.password_change,
            "/backup": self.create_backup,
        }
        fn = actions.get(path)
        if fn: return fn(user, form)
        self.send_html(self.layout(user,"Not Found",'<div class="card">Action not found.</div>'),404)

    def login_page(self, error=""):
        error_html = f'<div class="notice error">{escape(error)}</div>' if error else ""
        body=f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
        <title>Sign in · MSS Lite</title><style>{CSS}</style></head><body><div class="login-wrap"><div class="login-card">
        <h1>MSS Lite</h1><div class="subtitle">Sign in to your local workspace</div>{error_html}
        <form method="post" action="/login"><div class="field"><label>Email</label><input name="email" type="email" required value="admin@mss.local"></div>
        <div class="field"><label>Password</label><input name="password" type="password" required></div>
        <button type="submit">Sign in</button></form>
        <p class="small">Initial password: <strong>ChangeMe123!</strong><br>Change it immediately after first login.</p>
        </div></div></body></html>"""
        self.send_html(body)

    def login_submit(self):
        form=self.parse_form()
        email=form.get("email","").strip()
        password=form.get("password","")
        con=db()
        user=con.execute("SELECT * FROM users WHERE email=? AND active=1",(email,)).fetchone()
        if not user or not verify_password(password,user["password_hash"]):
            con.close()
            return self.login_page("Invalid email or password.")
        token=secrets.token_urlsafe(32)
        con.execute("DELETE FROM sessions WHERE expires_at<=?",(utcnow(),))
        con.execute("INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
                    (hashlib.sha256(token.encode()).hexdigest(),user["id"],(datetime.now(timezone.utc)+timedelta(days=7)).replace(microsecond=0).isoformat(),utcnow()))
        con.commit(); con.close()
        self.audit(user["id"],"login","user",user["id"])
        cookie=f"mss_session={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800"
        self.redirect("/",cookie)

    def logout(self):
        raw=self.headers.get("Cookie",""); jar=cookies.SimpleCookie()
        try: jar.load(raw)
        except Exception: pass
        if jar.get("mss_session"):
            token_hash=hashlib.sha256(jar["mss_session"].value.encode()).hexdigest()
            con=db(); con.execute("DELETE FROM sessions WHERE token_hash=?",(token_hash,)); con.commit(); con.close()
        self.redirect("/login","mss_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0")

    def dashboard(self,user,qs):
        con=db()
        docs=con.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
        published=con.execute("SELECT COUNT(*) FROM documents WHERE status='published'").fetchone()[0]
        open_tasks=con.execute("SELECT COUNT(*) FROM tasks WHERE status!='completed'").fetchone()[0]
        overdue=con.execute("SELECT COUNT(*) FROM tasks WHERE status!='completed' AND due_date IS NOT NULL AND due_date<date('now')").fetchone()[0]
        training=con.execute("SELECT COUNT(*) FROM training_assignments WHERE status!='completed'").fetchone()[0]
        recent_docs=con.execute("""SELECT documents.*,users.name owner FROM documents LEFT JOIN users ON users.id=documents.owner_id ORDER BY updated_at DESC LIMIT 5""").fetchall()
        my_tasks=con.execute("""SELECT tasks.*,users.name assignee FROM tasks LEFT JOIN users ON users.id=tasks.assigned_to
                               WHERE assigned_to=? AND status!='completed' ORDER BY due_date IS NULL,due_date LIMIT 5""",(user["id"],)).fetchall()
        con.close()
        metrics=f"""<div class="grid">
          <div class="card"><div class="metric-label">Documents</div><div class="metric-value">{docs}</div></div>
          <div class="card"><div class="metric-label">Published</div><div class="metric-value">{published}</div></div>
          <div class="card"><div class="metric-label">Open Tasks</div><div class="metric-value">{open_tasks}</div></div>
          <div class="card"><div class="metric-label">Training Due</div><div class="metric-value">{training}</div></div>
        </div>"""
        doc_rows="".join(f"<tr><td>{escape(r['title'])}</td><td>{escape(r['category'])}</td><td>{status_badge(r['status'])}</td><td>{escape(r['owner'] or '—')}</td></tr>" for r in recent_docs) or '<tr><td colspan="4" class="empty">No documents yet.</td></tr>'
        task_rows="".join(f"<tr><td>{escape(r['title'])}</td><td>{escape(r['due_date'] or '—')}</td><td>{status_badge('overdue' if r['due_date'] and r['due_date']<datetime.now().date().isoformat() else r['status'])}</td></tr>" for r in my_tasks) or '<tr><td colspan="3" class="empty">No assigned tasks.</td></tr>'
        content=metrics+f"""<div class="two-col"><section class="card"><h2>Recent documents</h2><table><tr><th>Title</th><th>Category</th><th>Status</th><th>Owner</th></tr>{doc_rows}</table></section>
        <section class="card"><h2>My tasks</h2><table><tr><th>Task</th><th>Due</th><th>Status</th></tr>{task_rows}</table>
        <p class="small">{overdue} organization task(s) overdue.</p></section></div>"""
        self.send_html(self.layout(user,"Dashboard",content,"Dashboard",qs.get("notice",[""])[0]))

    def documents(self,user,qs):
        con=db()
        rows=con.execute("""SELECT documents.*,users.name owner FROM documents LEFT JOIN users ON users.id=documents.owner_id ORDER BY updated_at DESC""").fetchall()
        users=con.execute("SELECT id,name FROM users WHERE active=1 ORDER BY name").fetchall()
        con.close()
        user_opts="".join(f'<option value="{u["id"]}">{escape(u["name"])}</option>' for u in users)
        trs=""
        for r in rows:
            file_link=f'<a href="/uploads/{quote(r["stored_filename"])}">Download</a>' if r["stored_filename"] else "—"
            status_actions=""
            if user["role"] in ("admin","editor"):
                status_actions=f"""<form class="inline" method="post" action="/documents/status">
                <input type="hidden" name="id" value="{r['id']}"><select name="status" style="width:auto;display:inline">
                {''.join(f'<option {"selected" if s==r["status"] else ""}>{s}</option>' for s in ["draft","review","published","archived"])}</select>
                <button class="secondary">Update</button></form>"""
            trs+=f"<tr><td><strong>{escape(r['title'])}</strong><div class='small'>{escape(r['description'])}</div></td><td>{escape(r['category'])}</td><td>{status_badge(r['status'])}</td><td>{escape(r['owner'] or '—')}</td><td>{escape(r['review_date'] or '—')}</td><td>{file_link}<br>{status_actions}</td></tr>"
        if not trs: trs='<tr><td colspan="6" class="empty">No documents yet.</td></tr>'
        create=""
        if user["role"] in ("admin","editor"):
            create=f"""<section class="card" style="margin-bottom:18px"><h2>Add document or policy</h2>
            <form method="post" action="/documents/create" enctype="multipart/form-data"><div class="form-grid">
            <div><label>Title</label><input name="title" required></div><div><label>Category</label><select name="category"><option>Policy</option><option>SOP</option><option>Guide</option><option>Checklist</option><option>Form</option><option>Other</option></select></div>
            <div class="full"><label>Description</label><textarea name="description"></textarea></div>
            <div><label>Owner</label><select name="owner_id">{user_opts}</select></div><div><label>Review date</label><input type="date" name="review_date"></div>
            <div class="full"><label>Optional file</label><input type="file" name="file"></div>
            <div class="full"><button>Add document</button></div></div></form></section>"""
        content=create+f"""<section class="card"><div class="toolbar"><h2>Document library</h2><span class="small">{len(rows)} record(s)</span></div>
        <table><tr><th>Document</th><th>Category</th><th>Status</th><th>Owner</th><th>Review</th><th>Actions</th></tr>{trs}</table></section>"""
        self.send_html(self.layout(user,"Documents",content,"Documents",qs.get("notice",[""])[0]))

    def document_create(self,user,form):
        if user["role"] not in ("admin","editor"): return self.send_html(self.layout(user,"Forbidden",'<div class="notice error">Permission denied.</div>'),403)
        title=form.getfirst("title","").strip()
        category=form.getfirst("category","Other")
        description=form.getfirst("description","")
        owner_id=form.getfirst("owner_id") or user["id"]
        review_date=form.getfirst("review_date") or None
        filename=stored=None
        item=form["file"] if "file" in form else None
        if item is not None and getattr(item,"filename",""):
            filename=os.path.basename(item.filename)
            stored=f"{secrets.token_hex(8)}_{filename}"
            with open(UPLOAD_DIR/stored,"wb") as out: shutil.copyfileobj(item.file,out)
        now=utcnow(); con=db()
        cur=con.execute("""INSERT INTO documents(title,category,description,status,owner_id,review_date,version,filename,stored_filename,created_at,updated_at)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?)""",(title,category,description,"draft",owner_id,review_date,1,filename,stored,now,now))
        con.commit(); doc_id=cur.lastrowid; con.close()
        self.audit(user["id"],"create","document",doc_id,title)
        self.redirect("/documents?notice=Document+added")

    def document_status(self,user,form):
        if user["role"] not in ("admin","editor"): return self.redirect("/documents")
        doc_id=int(form.get("id")); status=form.get("status")
        con=db(); con.execute("UPDATE documents SET status=?,version=version+1,updated_at=? WHERE id=?",(status,utcnow(),doc_id)); con.commit(); con.close()
        self.audit(user["id"],"status_change","document",doc_id,status)
        self.redirect("/documents?notice=Document+status+updated")

    def tasks(self,user,qs):
        con=db()
        rows=con.execute("""SELECT tasks.*,users.name assignee FROM tasks LEFT JOIN users ON users.id=tasks.assigned_to
                            ORDER BY status='completed',due_date IS NULL,due_date""").fetchall()
        users=con.execute("SELECT id,name FROM users WHERE active=1 ORDER BY name").fetchall(); con.close()
        opts="".join(f'<option value="{u["id"]}">{escape(u["name"])}</option>' for u in users)
        trs=""
        today=datetime.now().date().isoformat()
        for r in rows:
            show_status="overdue" if r["status"]!="completed" and r["due_date"] and r["due_date"]<today else r["status"]
            action=f"""<form class="inline" method="post" action="/tasks/status"><input type="hidden" name="id" value="{r['id']}">
            <select name="status" style="width:auto;display:inline">{''.join(f'<option {"selected" if s==r["status"] else ""}>{s}</option>' for s in ["open","in_progress","completed"])}</select><button class="secondary">Update</button></form>"""
            trs+=f"<tr><td><strong>{escape(r['title'])}</strong><div class='small'>{escape(r['description'])}</div></td><td>{escape(r['assignee'] or '—')}</td><td>{escape(r['due_date'] or '—')}</td><td>{escape(r['priority'].title())}</td><td>{status_badge(show_status)}</td><td>{action}</td></tr>"
        if not trs: trs='<tr><td colspan="6" class="empty">No tasks yet.</td></tr>'
        create=f"""<section class="card" style="margin-bottom:18px"><h2>Create task</h2><form method="post" action="/tasks/create"><div class="form-grid">
        <div><label>Task title</label><input name="title" required></div><div><label>Assigned to</label><select name="assigned_to">{opts}</select></div>
        <div class="full"><label>Description</label><textarea name="description"></textarea></div><div><label>Due date</label><input type="date" name="due_date"></div>
        <div><label>Priority</label><select name="priority"><option>normal</option><option>high</option><option>low</option></select></div>
        <div class="full"><button>Create task</button></div></div></form></section>"""
        content=create+f'<section class="card"><h2>Tasks</h2><table><tr><th>Task</th><th>Assigned</th><th>Due</th><th>Priority</th><th>Status</th><th>Action</th></tr>{trs}</table></section>'
        self.send_html(self.layout(user,"Tasks",content,"Tasks",qs.get("notice",[""])[0]))

    def task_create(self,user,form):
        con=db(); cur=con.execute("""INSERT INTO tasks(title,description,assigned_to,due_date,priority,status,created_at) VALUES(?,?,?,?,?,'open',?)""",
                                  (form.get("title"),form.get("description"),form.get("assigned_to") or None,form.get("due_date") or None,form.get("priority","normal"),utcnow()))
        con.commit(); task_id=cur.lastrowid; con.close(); self.audit(user["id"],"create","task",task_id,form.get("title",""))
        self.redirect("/tasks?notice=Task+created")

    def task_status(self,user,form):
        status=form.get("status"); completed=utcnow() if status=="completed" else None
        con=db(); con.execute("UPDATE tasks SET status=?,completed_at=? WHERE id=?",(status,completed,int(form.get("id")))); con.commit(); con.close()
        self.audit(user["id"],"status_change","task",int(form.get("id")),status); self.redirect("/tasks?notice=Task+updated")

    def training(self,user,qs):
        con=db()
        courses=con.execute("SELECT * FROM courses ORDER BY title").fetchall()
        users=con.execute("SELECT id,name FROM users WHERE active=1 ORDER BY name").fetchall()
        rows=con.execute("""SELECT ta.*,courses.title course,users.name trainee FROM training_assignments ta
                            JOIN courses ON courses.id=ta.course_id JOIN users ON users.id=ta.user_id
                            ORDER BY ta.status='completed',ta.due_date""").fetchall(); con.close()
        course_opts="".join(f'<option value="{c["id"]}">{escape(c["title"])}</option>' for c in courses)
        user_opts="".join(f'<option value="{u["id"]}">{escape(u["name"])}</option>' for u in users)
        trs=""
        for r in rows:
            action=f"""<form class="inline" method="post" action="/training/status"><input type="hidden" name="id" value="{r['id']}">
            <select name="status" style="width:auto;display:inline">{''.join(f'<option {"selected" if s==r["status"] else ""}>{s}</option>' for s in ["assigned","in_progress","completed"])}</select><button class="secondary">Update</button></form>"""
            trs+=f"<tr><td>{escape(r['course'])}</td><td>{escape(r['trainee'])}</td><td>{escape(r['due_date'] or '—')}</td><td>{status_badge(r['status'])}</td><td>{action}</td></tr>"
        if not trs: trs='<tr><td colspan="5" class="empty">No assignments.</td></tr>'
        setup=""
        if user["role"] in ("admin","editor"):
            setup=f"""<div class="two-col" style="margin-top:0;margin-bottom:18px"><section class="card"><h2>Create course</h2>
            <form method="post" action="/training/course/create"><label>Course title</label><input name="title" required>
            <label style="margin-top:12px">Description</label><textarea name="description"></textarea><button>Create course</button></form></section>
            <section class="card"><h2>Assign training</h2><form method="post" action="/training/assign"><label>Course</label><select name="course_id">{course_opts}</select>
            <label style="margin-top:12px">Employee</label><select name="user_id">{user_opts}</select>
            <label style="margin-top:12px">Due date</label><input type="date" name="due_date"><button style="margin-top:12px">Assign</button></form></section></div>"""
        content=setup+f'<section class="card"><h2>Training assignments</h2><table><tr><th>Course</th><th>Employee</th><th>Due</th><th>Status</th><th>Action</th></tr>{trs}</table></section>'
        self.send_html(self.layout(user,"Training",content,"Training",qs.get("notice",[""])[0]))

    def course_create(self,user,form):
        if user["role"] not in ("admin","editor"): return self.redirect("/training")
        con=db(); cur=con.execute("INSERT INTO courses(title,description,created_at) VALUES(?,?,?)",(form.get("title"),form.get("description"),utcnow())); con.commit(); cid=cur.lastrowid; con.close()
        self.audit(user["id"],"create","course",cid,form.get("title","")); self.redirect("/training?notice=Course+created")

    def training_assign(self,user,form):
        if user["role"] not in ("admin","editor"): return self.redirect("/training")
        con=db()
        try:
            cur=con.execute("INSERT INTO training_assignments(course_id,user_id,due_date,status) VALUES(?,?,?,'assigned')",(form.get("course_id"),form.get("user_id"),form.get("due_date") or None))
            con.commit(); aid=cur.lastrowid; notice="Training assigned"
        except sqlite3.IntegrityError:
            aid=None; notice="That training is already assigned"
        con.close()
        if aid: self.audit(user["id"],"assign","training",aid)
        self.redirect("/training?notice="+quote(notice))

    def training_status(self,user,form):
        status=form.get("status"); completed=utcnow() if status=="completed" else None
        con=db(); con.execute("UPDATE training_assignments SET status=?,completed_at=? WHERE id=?",(status,completed,int(form.get("id")))); con.commit(); con.close()
        self.audit(user["id"],"status_change","training",int(form.get("id")),status); self.redirect("/training?notice=Training+updated")

    def search(self,user,qs):
        q=qs.get("q",[""])[0].strip()
        results=[]
        if q:
            like=f"%{q}%"; con=db()
            for r in con.execute("SELECT id,title,description,status FROM documents WHERE title LIKE ? OR description LIKE ?",(like,like)):
                results.append(("Document",r["title"],r["description"],r["status"],"/documents"))
            for r in con.execute("SELECT id,title,description,status FROM tasks WHERE title LIKE ? OR description LIKE ?",(like,like)):
                results.append(("Task",r["title"],r["description"],r["status"],"/tasks"))
            for r in con.execute("SELECT id,title,description,'course' status FROM courses WHERE title LIKE ? OR description LIKE ?",(like,like)):
                results.append(("Course",r["title"],r["description"],r["status"],"/training"))
            con.close()
        cards="".join(f'<div class="result"><div class="small">{escape(kind)} · {escape(status)}</div><strong><a href="{url}">{escape(title)}</a></strong><p>{escape(desc)}</p></div>' for kind,title,desc,status,url in results)
        if q and not cards: cards='<div class="empty">No matching records.</div>'
        content=f"""<section class="card"><form method="get" action="/search"><div class="toolbar"><input name="q" value="{escape(q)}" placeholder="Search documents, tasks, and training..." style="flex:1"><button>Search</button></div></form>
        <div class="search-results">{cards}</div></section>"""
        self.send_html(self.layout(user,"Search",content,"Search"))

    def reports(self,user,qs):
        con=db()
        stats={
            "Documents":con.execute("SELECT COUNT(*) FROM documents").fetchone()[0],
            "Published documents":con.execute("SELECT COUNT(*) FROM documents WHERE status='published'").fetchone()[0],
            "Open tasks":con.execute("SELECT COUNT(*) FROM tasks WHERE status!='completed'").fetchone()[0],
            "Completed tasks":con.execute("SELECT COUNT(*) FROM tasks WHERE status='completed'").fetchone()[0],
            "Training assigned":con.execute("SELECT COUNT(*) FROM training_assignments WHERE status!='completed'").fetchone()[0],
            "Training completed":con.execute("SELECT COUNT(*) FROM training_assignments WHERE status='completed'").fetchone()[0],
            "Active users":con.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0],
        }
        con.close()
        rows="".join(f'<div class="kpi-row"><span>{escape(k)}</span><strong>{v}</strong></div>' for k,v in stats.items())
        content=f"""<div class="two-col" style="margin-top:0"><section class="card"><h2>Organization summary</h2><div class="kpi-list">{rows}</div></section>
        <section class="card"><h2>Export data</h2><p class="small">Download CSV files for analysis or backup.</p>
        <div class="actions"><a class="button secondary" href="/export/documents">Documents CSV</a><a class="button secondary" href="/export/tasks">Tasks CSV</a>
        <a class="button secondary" href="/export/training">Training CSV</a></div>
        <form method="post" action="/backup" style="margin-top:22px"><button>Create database backup</button></form></section></div>"""
        self.send_html(self.layout(user,"Reports",content,"Reports",qs.get("notice",[""])[0]))

    def admin(self,user,qs):
        if user["role"]!="admin": return self.send_html(self.layout(user,"Forbidden",'<div class="notice error">Administrator access required.</div>'),403)
        con=db()
        users=con.execute("SELECT id,name,email,role,active,created_at FROM users ORDER BY name").fetchall()
        logs=con.execute("""SELECT audit_log.*,users.name FROM audit_log LEFT JOIN users ON users.id=audit_log.user_id ORDER BY audit_log.id DESC LIMIT 20""").fetchall()
        con.close()
        user_rows="".join(f"<tr><td>{escape(r['name'])}</td><td>{escape(r['email'])}</td><td>{status_badge(r['role'])}</td><td>{'Yes' if r['active'] else 'No'}</td></tr>" for r in users)
        log_rows="".join(f"<tr><td>{escape(r['created_at'])}</td><td>{escape(r['name'] or 'System')}</td><td>{escape(r['action'])}</td><td>{escape(r['entity_type'])}</td><td>{escape(r['detail'])}</td></tr>" for r in logs)
        content=f"""<div class="two-col" style="margin-top:0"><section class="card"><h2>Add user</h2><form method="post" action="/admin/user/create">
        <label>Name</label><input name="name" required><label style="margin-top:10px">Email</label><input type="email" name="email" required>
        <label style="margin-top:10px">Temporary password</label><input type="password" name="password" required minlength="10">
        <label style="margin-top:10px">Role</label><select name="role"><option>viewer</option><option>editor</option><option>admin</option></select>
        <button style="margin-top:12px">Add user</button></form></section>
        <section class="card"><h2>Change my password</h2><form method="post" action="/admin/password">
        <label>Current password</label><input type="password" name="current" required><label style="margin-top:10px">New password</label><input type="password" name="new" required minlength="12">
        <button style="margin-top:12px">Change password</button></form></section></div>
        <section class="card" style="margin-top:18px"><h2>Users</h2><table><tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th></tr>{user_rows}</table></section>
        <section class="card" style="margin-top:18px"><h2>Recent audit activity</h2><table><tr><th>Time</th><th>User</th><th>Action</th><th>Entity</th><th>Detail</th></tr>{log_rows}</table></section>"""
        self.send_html(self.layout(user,"Administration",content,"Administration",qs.get("notice",[""])[0]))

    def user_create(self,user,form):
        if user["role"]!="admin": return self.redirect("/")
        try:
            con=db(); cur=con.execute("INSERT INTO users(name,email,password_hash,role,created_at) VALUES(?,?,?,?,?)",
                (form.get("name"),form.get("email").lower(),hash_password(form.get("password")),form.get("role","viewer"),utcnow()))
            con.commit(); uid=cur.lastrowid; con.close(); self.audit(user["id"],"create","user",uid,form.get("email",""))
            self.redirect("/admin?notice=User+created")
        except sqlite3.IntegrityError:
            self.redirect("/admin?notice=Email+already+exists")

    def password_change(self,user,form):
        con=db(); row=con.execute("SELECT password_hash FROM users WHERE id=?",(user["id"],)).fetchone()
        if not verify_password(form.get("current",""),row["password_hash"]):
            con.close(); return self.redirect("/admin?notice=Current+password+is+incorrect")
        if len(form.get("new",""))<12:
            con.close(); return self.redirect("/admin?notice=New+password+must+be+at+least+12+characters")
        con.execute("UPDATE users SET password_hash=? WHERE id=?",(hash_password(form.get("new")),user["id"]))
        con.execute("DELETE FROM sessions WHERE user_id=?",(user["id"],))
        con.commit(); con.close(); self.audit(user["id"],"password_change","user",user["id"])
        self.redirect("/login","mss_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0")

    def download_file(self,stored):
        user=self.require_user()
        if not user:return
        safe=os.path.basename(stored); path=UPLOAD_DIR/safe
        if not path.exists(): return self.send_html("Not found",404)
        con=db(); row=con.execute("SELECT filename FROM documents WHERE stored_filename=?",(safe,)).fetchone(); con.close()
        data=path.read_bytes(); self.send_response(200)
        self.send_header("Content-Type",mimetypes.guess_type(row["filename"] if row else safe)[0] or "application/octet-stream")
        self.send_header("Content-Disposition",f'attachment; filename="{(row["filename"] if row else safe).replace(chr(34),"")}"')
        self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)

    def export_csv(self,kind):
        user=self.require_user()
        if not user:return
        con=db()
        if kind=="documents":
            rows=con.execute("SELECT id,title,category,status,review_date,version,created_at,updated_at FROM documents").fetchall()
        elif kind=="tasks":
            rows=con.execute("SELECT id,title,due_date,priority,status,created_at,completed_at FROM tasks").fetchall()
        elif kind=="training":
            rows=con.execute("""SELECT ta.id,courses.title course,users.name employee,ta.due_date,ta.status,ta.completed_at FROM training_assignments ta JOIN courses ON courses.id=ta.course_id JOIN users ON users.id=ta.user_id""").fetchall()
        else:
            con.close(); return self.send_html("Not found",404)
        con.close(); out=io.StringIO(); writer=csv.writer(out)
        if rows:
            writer.writerow(rows[0].keys())
            for r in rows: writer.writerow(tuple(r))
        data=out.getvalue().encode()
        self.send_response(200); self.send_header("Content-Type","text/csv; charset=utf-8")
        self.send_header("Content-Disposition",f'attachment; filename="mss_{kind}.csv"')
        self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data)

    def create_backup(self,user,form):
        stamp=datetime.now().strftime("%Y%m%d-%H%M%S")
        target=BACKUP_DIR/f"mss-lite-{stamp}.db"
        con=db(); dest=sqlite3.connect(target); con.backup(dest); dest.close(); con.close()
        self.audit(user["id"],"backup","database",None,target.name)
        self.redirect("/reports?notice="+quote(f"Backup created: {target.name}"))

def main():
    init_db()
    server=ThreadingHTTPServer((HOST,PORT),MSSHandler)
    print("="*58)
    print(f"MSS Lite is running at http://{HOST}:{PORT}")
    print("Initial login: admin@mss.local / ChangeMe123!")
    print("Press Ctrl+C to stop.")
    print("="*58)
    try: server.serve_forever()
    except KeyboardInterrupt: print("\nMSS Lite stopped.")
    finally: server.server_close()

if __name__ == "__main__":
    main()
