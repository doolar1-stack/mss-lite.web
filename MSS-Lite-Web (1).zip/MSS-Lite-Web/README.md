# MSS Lite Web

A deployable web version of MSS Lite for one organization.

## What is included

- Secure login and role-based access
- Dashboard
- Documents, policies, SOPs, guides, checklists, forms, and attachments
- Document statuses and version increments
- Tasks, assignments, priorities, and due dates
- Training courses and completion tracking
- Search, CSV reports, backups, users, and audit activity
- Docker deployment files
- Render Blueprint configuration with persistent storage

## Default administrator

- Email: `admin@mss.local`
- Password: `ChangeMe123!`

Change the password immediately after your first login.

## Deploy on Render

Render deploys from a Git repository. The easiest Mac workflow is:

1. Create a free GitHub account if you do not already have one.
2. On GitHub, create a new **private** repository named `mss-lite`.
3. Upload every file from this folder into that repository. Keep `app.py`, `Dockerfile`, and `render.yaml` at the top level.
4. Create a Render account and connect it to GitHub.
5. In Render, choose **New**, then **Blueprint**.
6. Select the `mss-lite` repository.
7. Render will read `render.yaml`. Review the service and create it.
8. When deployment finishes, open the `onrender.com` address shown by Render.
9. Sign in with the default administrator account and change the password immediately.

## Important hosting note

This package uses SQLite and uploaded files. They must be stored on a persistent disk. The included Render Blueprint uses a paid Starter web service with a 1 GB persistent disk. A free Render web service does not preserve local file changes across restarts or redeployments.

## Test locally on a Mac

Python 3.10 or newer is required.

```bash
cd path/to/MSS-Lite-Web
python3 app.py
```

Then open `http://localhost:8501` in Safari.

## Data location

When deployed with the included Render Blueprint:

- Database: `/var/data/data/mss_lite.db`
- Uploads: `/var/data/uploads/`
- Backups: `/var/data/backups/`

## Security limits

This is an MVP for a small organization. It should not yet store highly sensitive regulated information. Before broader production use, add managed database storage, CSRF protection, stronger account recovery, automated off-site backups, rate limiting, security monitoring, and formal testing.
